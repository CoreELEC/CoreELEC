.. plugin.video.netflix documentation master file, created by
   sphinx-quickstart on Wed Apr 26 16:27:25 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

:github_url: https://github.com/asciidisco/plugin.video.netflix

Code Docs
=========

.. automodule:: resources.lib.utils
  :members:
  :private-members:

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
